CREATE PROCEDURE sp_createUser(IN p_name VARCHAR(200), IN p_email VARCHAR(200), IN p_password VARCHAR(200))
  BEGIN
	IF ( select EXISTS (SELECT * FROM advisors WHERE email = p_email)) THEN
    
    SELECT 'Email Exists !';
    
    ELSE
    
    	INSERT INTO advisors
        (
         	advisorname,
            email,
            password  
        )
        VALUES
        (
            p_name,
            p_email,
            p_password
         );
     END IF;
END;

